//
//  ViewController.swift
//  Flight App
//
//  Created by Jaspreet on 2020-08-24.
//  Copyright © 2020 Jaspreet. All rights reserved.
//
import Alamofire
import SwiftyJSON
import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var from: UITextField!
    @IBOutlet weak var to: UITextField!
    
    @IBOutlet weak var date: UIDatePicker!
    
    @IBOutlet weak var passengers: UILabel!
    @IBAction func search(_ sender: Any) {
        let searchVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "searchView") as! SearchViewController
        self.navigationController?.pushViewController(searchVC, animated: true)
        
        
        
       let URL = "http://partners.api.skyscanner.net/apiservices/browsequotes/v1.0/FR/eur/en-US/uk/us/anytime/anytime?apikey=prtl6749387986743898559646983194"
            
       print(URL)
       
           request(URL).responseJSON {
                  // 1. store the data from the internet in the
                  // response variable
                  response in
                  
                  // 2. get the data out of the variable
                  guard let apiData = response.result.value else {
                      print("Error getting data from the URL")
                      return
                  }
              
                  // OUTPUT the json response to the terminal
                  print(apiData)
                  
                  
                  // GET something out of the JSON response
                  let jsonResponse = JSON(apiData)}
        
        
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

