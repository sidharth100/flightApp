//
//  SearchViewController.swift
//  Flight App
//
//  Created by Sidharth Mehta on 26/08/20.
//  Copyright © 2020 Jaspreet. All rights reserved.
//

import UIKit

class SearchViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var table: UITableView!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        table.delegate = self
        table.dataSource = self
        // Do any additional setup after loading the view.
    }
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 0 //list1.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = table.dequeueReusableCell(withIdentifier: "id", for: indexPath) as! TableViewCell
       /*
        let rslt = list1[indexPath.row]
        cell.amount.text = String(rslt.amount)
        cell.fname.text = rslt.name
        
        /*
        cell.img.animationImages = imageArray()
        cell.img.animationDuration = 3.0
        cell.img.startAnimating()
        
        */
        let formatter = DateFormatter()
               // initially set the format based on your datepicker date / server String
               formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"

        let myString = formatter.string(from: rslt.time!) // string purpose I add here
               // convert your string to date
               let yourDate = formatter.date(from: myString)
               //then again set the date format whhich type of output you need
               formatter.dateFormat = "dd-MMM-yyyy HH:mm:ss"
               // again convert your date to string
               let myStringafd = formatter.string(from: yourDate!)
                cell.date.text = myStringafd
        
        
        
        
        
        */
        return cell
        
        
    }
    
    
    
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90
    }
    
    
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("am here")
       //  rslt = list1[indexPath.row]
      //  performSegue(withIdentifier: "masterToDonate", sender: rslt)
        
    }
    
    
    
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
